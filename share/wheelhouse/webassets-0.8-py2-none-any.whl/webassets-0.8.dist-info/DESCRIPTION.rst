Merges, minifies and compresses Javascript and CSS files, supporting a variety of different filters, including YUI, jsmin, jspacker or CSS tidy. Also supports URL rewriting in CSS files.


