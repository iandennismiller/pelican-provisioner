feedgenerator-py3k
==================

Feedgenerator-py3k is a standalone version of Django's feedgenerator.
It is based on the current Django Version 1.5.dev20120824122350.

The previous feedgenerator 1.2.1 is based on rather old code, and
during the port to Python 3 it became obvious that (at least) the handling
of unicode strings has to be refactored.

Django has evolved since, so I decided to create a new standalone version
which is based upon modern code.

See http://parenchym.com/pymblog/ for details.


